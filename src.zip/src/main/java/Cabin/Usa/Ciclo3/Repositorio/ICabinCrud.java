package Cabin.Usa.Ciclo3.Repositorio;

import Cabin.Usa.Ciclo3.Modelo.Cabin;
import org.springframework.data.repository.CrudRepository;


public interface ICabinCrud extends CrudRepository<Cabin, Integer>{
    
}
