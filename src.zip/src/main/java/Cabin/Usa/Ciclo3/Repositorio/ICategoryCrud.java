package Cabin.Usa.Ciclo3.Repositorio;

import Cabin.Usa.Ciclo3.Modelo.Categoria;
import org.springframework.data.repository.CrudRepository;


public interface ICategoryCrud extends CrudRepository<Categoria, Integer>{
    
}
