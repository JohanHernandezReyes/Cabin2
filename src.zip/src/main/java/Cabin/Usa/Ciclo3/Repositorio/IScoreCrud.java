package Cabin.Usa.Ciclo3.Repositorio;

import Cabin.Usa.Ciclo3.Modelo.Score;
import org.springframework.data.repository.CrudRepository;


public interface IScoreCrud extends CrudRepository<Score, Integer>{
    
}

