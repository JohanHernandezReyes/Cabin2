package Cabin.Usa.Ciclo3.Repositorio;

import Cabin.Usa.Ciclo3.Modelo.Cliente;
import org.springframework.data.repository.CrudRepository;


public interface IClienteCrud extends CrudRepository<Cliente, Integer>{
    
}

